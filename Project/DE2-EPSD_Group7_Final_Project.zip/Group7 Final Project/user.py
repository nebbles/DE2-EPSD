'''    Marks the start of comment section
-------------------------------------------------------
Name: User's own program for Lab 4 Exercise 4
Creator:
Date:
Revision:
-------------------------------------------------------
Put comments here to explain what this does
-------------------------------------------------------
'''
#  Put the name of the python file below between ' '
# execfile('balance.py')
# execfile('beat_detect_1.py')
execfile('test_beat.py')